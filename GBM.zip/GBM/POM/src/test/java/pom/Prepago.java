package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Prepago extends Base{

	By prepago = By.xpath("//a[@class='submenu__link mi-nw-phone-price']");
	
	public Prepago(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void prepagoInicial() throws InterruptedException {	
		click(prepago);
		Thread.sleep(2000);
		if(isDisplayed(prepago)) {
			System.out.print(true);
		}
		
	}
	
	public String mensaje() {
		return "";
	}
	
	}
