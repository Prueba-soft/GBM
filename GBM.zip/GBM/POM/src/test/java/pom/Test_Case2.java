package pom;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class Test_Case2 {
	
	private WebDriver driver;
	Prepago prepago;
	

	@Before
	public void setUp() throws Exception {
		prepago = new Prepago(driver);
		driver = prepago.chormeDriverConection();
		prepago.visit("https://qa-everis-tienda-movistar.canalesdigitales.com.mx/");
	}
	

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

	@Test
	public void test() throws InterruptedException {
		prepago.prepagoInicial();
		
	}

}
