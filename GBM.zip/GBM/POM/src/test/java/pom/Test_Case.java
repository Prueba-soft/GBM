package pom;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class Test_Case {
	
	private WebDriver driver;
	Recarga recarga;
	

	@Before
	public void setUp() throws Exception {
		recarga = new Recarga(driver);
		driver = recarga.chormeDriverConection();
		recarga.visit("https://qa-everis-tienda-movistar.canalesdigitales.com.mx/");
	}
	

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

	@Test
	public void test() throws InterruptedException {
		recarga.recargaInicial();
		
	}

}
