package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Recarga extends Base{
	
	By recarga = By.xpath("//a[@class='submenu__link mi-nw-phone-price']");
	
	public Recarga(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void recargaInicial() throws InterruptedException {	
		click(recarga);
		Thread.sleep(8000);
		if(isDisplayed(recarga)) {
			System.out.print(true);
		}
		
	}
	
	public String mensaje() {
		return "";
	}
	
	}

