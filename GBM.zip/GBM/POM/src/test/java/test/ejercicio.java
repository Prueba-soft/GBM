package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ejercicio {
	
	private WebDriver driver;
	
	@Before 
	public void setUP () {
		
		String page = ("https://www.amazon.com.mx");
		System.setProperty("webdriver.chrome.driver", "C:/Users/dtellezv/Desktop/eclipse/prueba.gbm/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(page);
					
	}
	
	@Test 
	public void amazonPage () throws InterruptedException {
		String busqueda = ("Pantallas");
		WebElement buscar = driver.findElement(By.id("twotabsearchtextbox"));
		buscar.clear();
		buscar.sendKeys(busqueda);
		buscar.submit();
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[1]")).getText();
		String palabra = driver.findElement(By.xpath("//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[3]")).getText();
		System.out.println(text + " " + palabra);
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	

}
