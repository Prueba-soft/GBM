package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_pmo {
	
				
private WebDriver driver;
	
	@Before 
	public void setUP () {
		
		String page = ("https://qa-everis-tienda-movistar.canalesdigitales.com.mx/");
		System.setProperty("webdriver.chrome.driver", "C:/Users/dtellezv/Desktop/eclipse/prueba.gbm/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(page);
					
	}
	
	@Test
	public void prepago() throws InterruptedException {
		By prepago = By.xpath("//a[@class='submenu__link mi-cell-prepago gtm-header-menu']");
		driver.findElement(prepago).click();
	
	}
	
	@Test
	public void pospago() {

		By pospago = By.xpath("//a[@class='submenu__link mi-nw-phone-movistar']");	
		driver.findElement(pospago).click();
		
	}

	@Test
	public void recargas() {
		
		By recarga = By.xpath("//a[@class='submenu__link mi-nw-phone-price']");
		driver.findElement(recarga).click();
	}
	
	@After
	
	public void cierre() {
		driver.quit();
	}

	
}