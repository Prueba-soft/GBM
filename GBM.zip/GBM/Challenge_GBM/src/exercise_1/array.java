package exercise_1;

public class array {
	
	public static void main(String[] args) {
	
		String[] Array = new String[]{"a", "b", "c", "d"};
		boolean found = false;
		String searchedValue = "a";

		for(String x : Array){
		    if(x.equals(searchedValue)){
		        found = true;
		        break;
 
	}
	}
		System.out.println(found);
	}
}
	