package exercise_1;
import  java.util.Scanner;

public class factorial_number {

	private static Scanner dato;

	public static void main(String[] args) {
	
		/*Variable que indica en n�mero almacenado*/
		int num=0;
		
		/*Variable que almacena el valor final*/
		int resultado=1;
		dato = new Scanner(System.in);
		
		/*Se imprime la instruccion*/
		System.out.println("Ingresar el n�mero a calcular el factorial");
		num = dato.nextInt();
		int numero = num;
		
		while(num !=0) {
			
			resultado= resultado*num;
			num --;			
			
		}
		
		/*Se imprime el resultado*/
		System.out.println("El factorial del n�mero "+numero+" es: "+ resultado);

	}

}
