package exercise_1;

public class sum_array {

	public static void main(String[] args) {

		int [] numero= {1,34,56,72,123};
		int total = 0;
		for (int contar = 0; contar<numero.length; contar++) {
			
			total+= numero[contar];
		}
		
		System.out.println("La suma del arreglo es:"+ " "+total);
		

	}

}
