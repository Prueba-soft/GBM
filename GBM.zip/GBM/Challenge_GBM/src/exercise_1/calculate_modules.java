package exercise_1;
import java.util.Scanner;

public class calculate_modules {

	private static Scanner in;

	public static void main(String[] args) {
	    {
	        in = new Scanner(System.in);
	        System.out.print("Introduce el primer n�mero: ");
	        int a = in.nextInt();  
			System.out.print("Introduce el segundo n�mero: ");
			int b = in.nextInt(); 
			int divided = a / b;
			int result = a - (divided * b);
			System.out.println("El resultado es: "+result); 
		}
	 }
	}

